%Best fit is a cubic function, limit to three parameters:
    %A*(x-B)^3 + C
% Probability of mass distribution: P(m) = m^-a for:
%a = 0.3 for m < 0.08 
%a = 1.3 for 0.08 > m > 0.5
%a = 2.35 for m > 0.5

% O = 32.7 - 22.6 solar masses, 200000 - 55000 solar luminosities
% B = 17.8 - 2.91 solar masses, 24000 - 42 solar luminosities
% A = 2.48 - 1.86 solar masses, 24 - 8.8 solar luminosities
% F = 1.59 - 1.1 solar masses, 5.1 - 1.4 solar luminosities
% G = 1.05 to 0.82 solar masses, 1.2 to 0.51 solar luminosities
% K = 0.76 to 0.53 solar masses, 0.38 to 0.11 solar luminosities
% M = 0.49 to 0.17 solar masses, 0.08 to 0.002 solar luminosity.


%n = number of data points, at least 50, no more than 500
% sig = 0.25*randn(1);
% O = (32.7 + 22.6)/2;
% B = (17.8 +2.91)/2;
% A = (2.48+1.86)/2;
% F = (1.59+1.1)/2;
% G = (1.05 + 0.82)/2;
% K = (0.76 + 0.53)/2;
% M = (0.49 + 0.17)/2;
% Om = O + sig*O;
% Bm = B + sig*B;
% Am = A + sig*A;
% Fm = F + sig*F;
% Gm = G + sig*G;
% Km = K + sig*K;
% Mm = M + sig*M;

%maybe instead of making 250 objects, make a 250 element long array
%[mass radius luminosity temperature x y z]

mycluster = Davis_Cluster();
mycluster.n = 1500;
mycluster.r = 24;%light years
%mycluster.construct
% figure

% figure
%h1 = axes;
mycluster.age = 10;
mycluster.agecluster;
%mycluster.findfit;

% mini= min(mycluster.newstars(:,1));
% maxi = max(mycluster.newstars(:,1));
% lengthm = length(mycluster.newstars(:,1));
% xvec = linspace(-3,3,lengthm);
figure
loglog(mycluster.stars(:,3),mycluster.stars(:,2),'.','linewidth',0.8); %luminosity v mass
set(gca,'xdir','reverse');
set(gca,'Color','k');
%plot(0.6,.1,'ro')

figure
loglog(mycluster.stars(:,1),mycluster.stars(:,2),'y.')
set(gca,'xdir','reverse');
set(gca,'Color','k');

% figure
% scatter3(mycluster.stars(:,5),mycluster.stars(:,6),mycluster.stars(:,7),'.')
% set(gca,'Color','k');

