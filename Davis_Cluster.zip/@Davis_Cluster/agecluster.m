function[offsequence]= agecluster(obj)
%changes the radius and luminosity of the stars based off of whether or not
%they're still on the main sequence, which is determined by their mass
obj.construct;
S = 5800;
offsequence = zeros(obj.n,1);
for ii = 1:obj.n
    if (1/obj.stars(ii,1))^2.5 < obj.age
        offsequence(ii) = 1;
    else
        offsequence(ii) = 0;
    end
end
for kk = 1:obj.n
    if offsequence(kk) == 1 %if it's off the main sequence
        if obj.stars(kk,1) > 8  % if the mass is greater than 8 solar masses
            obj.stars(kk,4) = (rand+0.5)*500 + 0.25*randn*100; %reassigning radius
            obj.stars(kk,3) = randi([3400 4200])/S + (0.25*randn*(3400+4200)/2)/S; %reassigning temperature
        else 
            obj.stars(kk,4) = (rand +0.5)*100+0.25*randn*100; %reassigning radius
            obj.stars(kk,3) = randi([3400 5240])/S +(0.25*randn*(3400+5240)/2)/S; %reassigning temperature
        end
        obj.stars(kk,2) = (obj.stars(kk,4)^2)*(obj.stars(kk,3)^4);
    end
end

end