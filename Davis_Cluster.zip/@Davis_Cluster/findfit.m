function findfit(obj)
obj.construct();
obj.newstars = obj.stars;  
[offsequence] = obj.agecluster();

for ii = 1:length(obj.stars)
    if offsequence(ii) == 1
        obj.newstars(ii,:) = [];    %if the star qualified to be altered, remove it from the sequence being fit
    end
end


theta0 = [0.25 0.6 0.1 ]; %it's not really important that the user chooses the initial parameters
len = 10000;
sigma = 1.5;

funch =@(theta,x) theta(1)*(x - theta(2))   + theta(3); %model form
model =@(theta,t) funch(theta,t);

chain = zeros(len,length(theta0));
chain(1,:) = theta0;

likelihood =@(theta,y,t) prod(1/sqrt(2*pi*sigma^2)*...
    exp(-(y-model(theta,t)).^2/(2*sigma^2)));%for the acceptance

mini = min(obj.newstars(:,1));maxi = max(obj.newstars(:,1)); lengthm = length(obj.newstars(:,1));
luminosity = log((obj.newstars(:,2)));    %the y axis
mass = linspace(-5,5,lengthm)'; %The x axis

jumpsz = abs(theta0/10);

for nn = 2:len
    theta = chain(nn-1,:);
    theta_test = theta+jumpsz.*randn(1,length(theta0));
    alpha = likelihood(theta_test,luminosity,mass)/likelihood(theta,luminosity,mass);
    
    if alpha> rand()
        chain(nn,:) = theta_test;
    else
        chain(nn,:) = theta;
    end
    chain(nn,:);
end
foundtheta = mean(chain);
obj.bestfit = model(foundtheta,mass);
end

