function clusterGui()
f = figure('Position',[100 100 600 600]);

title = uicontrol('Style','text','String','Bitchin HR diagram','bold',...
    'FontSize',14,'Position',[120 500 10 80]);
starstext = uicontrol('Style','text','String','Number of Elements',...
    'Position',[15 450 40 30]);
radiustext = uicontrol('Style','text','String','Radius of the Cluster',...
    'Position',[15 400 40 30]);
agetext 





    function property2gui()  %Converts the properties of the class to strings in the gui
        parameter1.String = num2str(obj.theta0(1));
        parameter2.String = num2str(obj.theta0(2));
        parameter3.String = num2str(obj.theta0(3));
        sigmabox.String = num2str(obj.sigma);
        njumpsbox.String = num2str(obj.njumps);
    end


    function gui2property() %converts strings of the GUI to properties in the class
        obj.theta0(1) = str2double(parameter1.String);
        obj.theta0(2) = str2double(parameter2.String);
        obj.theta0(3) = str2double(parameter3.String);
        obj.sigma = str2double(sigmabox.String);
        obj.njumps = str2double(njumpsbox.String);
    end
