classdef Davis_Cluster < handle
    %Constructs the matrix that contains all of the information for all of
    %the stars
    
    properties
        n %number of data points
        m %number of solar masses in the system
        r %radius of the system
        age %age of the cluster
        main
        spectype %an array that holds the spectral type of the data points
        stars %the array that holds the information about the star
        bestfit
        newstars
    end
    
    methods
        function outputArg = method1(obj,inputArg)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            outputArg = obj.Property1 + inputArg;
        end
    end
end

