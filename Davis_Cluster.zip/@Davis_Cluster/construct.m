function construct(obj)
%constructs two initial arrays that contains all the stars' info, one that
%contains spectral type and another that contains information such as
%mass,radius, luminosity, temperature, and coordinates.
%Constants:

sig = 0.25*randn(1);
%masses of the different spectral types of stars
O = (32.7 + 22.6)/2;    Om = O + sig*O;
B = (17.8 + 2.91)/2;     Bm = B + sig*B;
A = (2.48+1.86)/2;      Am = A + sig*A;
F = (1.59+1.1)/2;       Fm = F + sig*F;
G = (1.05 + 0.82)/2;    Gm = G + sig*G;
K = (0.76 + 0.53)/2;    Km = K + sig*K;
M = (0.49 + 0.17)/2;    Mm = M + sig*M;

obj.spectype = zeros(obj.n,1); %creates the matrix that will hold the star info

P =@(a,m) m^(-a); %mass distribution
PO = P(2.35,Om);PB = P(2.35,Bm);PA = P(2.35,Am);
PF = P(2.35,Fm);PG = P(2.35,Gm);PK = P(1.3,Km);
PM = P(1.3,Mm);

sums = sum(PO + PB + PA + PF +PG +PK +PM);
rat = obj.n/(sums); %scalar ratio to makes sure thenumber of stars made based
%on the probability actually matches the number of stars input by the user

PO = ceil(PO*rat); PB = ceil(PB*rat);PA = ceil(PA*rat);
PF = ceil(PF*rat); PG = ceil(PG*rat); PK = ceil(PK*rat);
PM = ceil(PM*rat);
sums = sum(PO + PB + PA + PF +PG +PK +PM);
if  sums ~= obj.n
    PM = PM + (obj.n - sums); %makes sure the the number of data points matches n
end

%------------------------------------------------------------------
obj.spectype = string(obj.spectype);  %assigning the spectral type numbers to an array
for j = 1:obj.n
    if PO ~= 0
        obj.spectype(j) = "O";
        PO = PO - 1;
    elseif PB ~= 0
        obj.spectype(j) = "B";
        PB = PB - 1;
    elseif PA ~= 0
        obj.spectype(j) = "A";
        PA = PA - 1;
    elseif PF ~= 0
        obj.spectype(j) = "F";
        PF = PF - 1;
    elseif PG ~= 0
        obj.spectype(j) = "G";
        PG = PG -1;
    elseif PK ~= 0
        obj.spectype(j) = "K";
        PK = PK -1;
    elseif PM ~= 0
        obj.spectype(j) = "M";
        PM = PM - 1;
    end
end

%---------------------------------------------------------------

%containing general information about different spectral types in arrays so
%that it's easier to call
%[mass_low mass_high luminosity_low luminosity_high temp_low temp_high]

S = 5800; %Temperature of the sun so that I can put the types in terms of solar temp

%randi only takes integer numbers,so divide by the solar
%constants after the random values have been assigned
Oa = [floor(22.6) floor(32.7) 55000 200000 37800 54000];
Ba = [ceil(2.91) ceil(17.8) 42 24000 11400 29200];
Aa = [ceil(1.86) floor(2.48) ceil(8.8) floor(24) 7920 9600];
Fa = [floor(100*1.1) floor(100*1.59) floor(100*1.4) floor(100*5.1) 6300 7350];
Ga = [floor(100*0.82) floor(100*1.05) floor(100*0.51) floor(100*1.2) 5440 6050];
Ka = [floor(100*0.53) floor(100*0.76) floor(100*0.11) floor(100*0.38) 4000 5240];
Ma = [floor(100*0.17) floor(100*0.49) floor(1000*0.002) floor(1000*0.08) 3400 3750];

%[mass luminosity temperature radius x y z]
obj.stars = zeros(obj.n,7); %number of data points by the number of properties

for jj = 1:obj.n
    rn = randn ;
    while obj.stars(jj,1) <= 0 || obj.stars(jj,2) <= 0 || obj.stars(jj,3) <=0
        if obj.spectype(jj) == "O"
            obj.stars(jj,1) = randi([Oa(1) Oa(2)]) +0.15*randn*Om;%assigning mass
            obj.stars(jj,2) = randi([Oa(3) Oa(4)]) +0.15*randn*Oa(4);%assigning luminosity
            obj.stars(jj,3) = randi([Oa(5) Oa(6)])/S + randn*0.25*((Oa(5)+Oa(6))/2)/S; %assigning temperature
        elseif obj.spectype(jj) == "B"
            obj.stars(jj,1) = randi([Ba(1) Ba(2)]) +0.15*randn*Bm;
            obj.stars(jj,2) = randi([Ba(3) Ba(4)]) +0.15*randn*Ba(4);
            obj.stars(jj,3) = randi([Ba(5) Ba(6)])/S + randn*0.25*((Ba(5)+Ba(6))/2)/S;
        elseif obj.spectype(jj) == "A"
            obj.stars(jj,1) = randi([Aa(1) Aa(2)]) +0.15*randn*Am;
            obj.stars(jj,2) = randi([Aa(3) Aa(4)]) +0.25*randn*Aa(4);
            obj.stars(jj,3) = randi([Aa(5) Aa(6)])/S + randn*0.25*((Aa(5)+Aa(6))/2)/S;
        elseif obj.spectype(jj) == "F"
            obj.stars(jj,1) = (randi([Fa(1) Fa(2)])+0.75*randn*Fm)/100;
            obj.stars(jj,2) = (randi([Fa(3) Fa(4)])+0.75*randn*Fa(4))/100 ;
            obj.stars(jj,3) = randi([Fa(5) Fa(6)])/S + randn*0.25*((Fa(5)+Fa(6))/2)/S;
        elseif obj.spectype(jj) == "G"
            obj.stars(jj,1) = (randi([Ga(1) Ga(2)])+5*randn*Gm)/100 ;
            obj.stars(jj,2) = (randi([Ga(3) Ga(4)])+0.75*randn*mean(Ga(4),Ga(3)))/100;
            obj.stars(jj,3) = randi([Ga(5) Ga(6)])/S + randn*0.25*((Ga(5)+Ga(6))/2)/S;
        elseif obj.spectype(jj) == "K"
            obj.stars(jj,1) = (randi([Ka(1) Ka(2)])+5*randn*Km)/100;
            obj.stars(jj,2) = (randi([Ka(3) Ka(4)])+0.75*randn*(mean(Ka(4),Ka(3))))/100 ;
            obj.stars(jj,3) = randi([Ka(5) Ka(6)])/S + randn*0.25*((Ka(5)+Ka(6))/2)/S;
        else
            obj.stars(jj,1) = (randi([Ma(1) Ma(2)])+5*randn*Mm)/100;
            obj.stars(jj,2) = (randi([Ma(3) Ma(4)])+0.75*randn*(mean(Ma(4),Ma(3))))/1000;
            obj.stars(jj,3) = randi([Ma(5) Ma(6)])/S + randn*0.25*((Ma(5)+Ma(6))/2)/S;
        end
    end
end

%-------------------------------------------------------------------
%Now to assign properties that isn't specific to the type of star
% R = sqrt(Luminosity)/temperature^2 =
% sqrt(obj.stars(kk,2))/obj.stars(kk,3)^2

for kk = 1:obj.n
    obj.stars(kk,4) = sqrt(obj.stars(kk,2))/obj.stars(kk,3)^2; %radius
    obj.stars(kk,5) = randn*obj.r;  %x coordinate
    obj.stars(kk,6) = randn*obj.r;  %y coordinate
    obj.stars(kk,7) = randn*obj.r;  %z coordinate
    %making sure the stars don't extend outside of the radius
    %of the cluster:
    while sqrt((obj.stars(kk,5))^2 +(obj.stars(kk,6))^2 +(obj.stars(kk,7))^2) > obj.r
        obj.stars(kk,5) = randn*obj.r;
        obj.stars(kk,6) = randn*obj.r;
        obj.stars(kk,7) = randn*obj.r;
    end
end
end